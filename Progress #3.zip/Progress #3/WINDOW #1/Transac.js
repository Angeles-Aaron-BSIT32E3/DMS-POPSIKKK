// Function to display the logout confirmation modal
function handleLogout(event) {
    event.preventDefault();
    document.getElementById('logoutModal').style.display = 'flex';
}

// Function to confirm logout and redirect to login page
function confirmLogout() {
    window.location.href = 'file:///C:/Users/angel/Downloads/DMS-E3/Login.html'; // Redirect to login page
}

// Function to cancel logout and hide the modal
function cancelLogout() {
    document.getElementById('logoutModal').style.display = 'none';
}

// For AMOUNT text-area
function validateAmount(input) {
    input.value = input.value.replace(/[^0-9]/g, '');
}
