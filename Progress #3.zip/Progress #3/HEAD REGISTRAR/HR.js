function sendNotification() {
    alert("Notification sent!");
}

// Function to display the logout confirmation modal
function handleLogout(event) {
event.preventDefault();
document.getElementById('logoutModal').style.display = 'flex';
 }

     // Function to confirm logout and redirect to login page
    function confirmLogout() {
    window.location.href = 'file:///C:/Users/angel/Downloads/DMS-E3/Login.html'; // Redirect to login page
 }

     // Function to cancel logout and hide the modal
    function cancelLogout() {
    document.getElementById('logoutModal').style.display = 'none';
}

// Open Notification Modal
function openNotificationModal() {
    document.getElementById("notificationModal").style.display = "block";
    document.getElementById("modalOverlay").style.display = "block"; 
}

// Close Notification Modal
function closeNotificationModal() {
    document.getElementById("notificationModal").style.display = "none";
    document.getElementById("modalOverlay").style.display = "none"; 
}

// Simulate sending notification
function notify() {
    const staffId = document.getElementById("staffId").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;
    const notifyIn = document.getElementById("notifyIn").value;

    // Process notification logic here

    alert("Notification Sent!");
    closeNotificationModal();
}

// Get elements
const openModalBtn = document.getElementById('openModalBtn');
const modal = document.getElementById('myModal');
const cancelBtn = document.getElementById('cancelBtn');

// Show the modal when the button is clicked
openModalBtn.addEventListener('click', () => {
    modal.style.display = 'flex'; // Make the modal visible and centered
});

// Hide the modal when the cancel button is clicked
cancelBtn.addEventListener('click', () => {
    modal.style.display = 'none'; // Hide the modal
});

// Optional: Hide modal if user clicks outside of the modal content
window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});