// FOR ADMIN CHANGE PASSWORD MODAL
document.getElementById('changePasswordBtn').addEventListener('click', function() {
    document.getElementById('changePasswordModal').style.display = 'block';
});

document.getElementById('closeModal').addEventListener('click', function() {
    document.getElementById('changePasswordModal').style.display = 'none';
});

// Close the modal if clicking outside of the modal-content
window.onclick = function(event) {
    if (event.target.className === 'modal') {
        document.getElementById('changePasswordModal').style.display = 'none';
    }
};


// For ADMIN LOCKED ACCOUNTS
